# DevOps Project - K8s (Submission)

## דרישות
- Kubernetes cluster עם 3 worker nodes (המבחן דורש 3 nodes — ניתן להשתמש ב-kind/k3d עם יצירת 3 workers או ב-cluster ענן עם 3 nodes)
- kubectl configured
- docker (אם בונים image מקומי)
- metrics-server מותקן ב-cluster בשביל HPA

## צעדים ריצתיים
1. בנה את ה-image (אופציונלי):
   ```bash
   cd nodejs-app
   docker build -t devops-node-app:latest .
   # push ל-registry אם צריך
   ```
2. פריסה:
   ```bash
   ./deploy.sh apply
   ```
3. בדיקות מהירות:
   ```bash
   kubectl -n devops-project get pods
   kubectl -n devops-project get pvc
   kubectl -n devops-project get hpa
   kubectl -n devops-project get cronjob
   ```
4. סימולציית נפילת MySQL:
   - תוכל למחוק את ה-pod: `kubectl -n devops-project delete pod -l app=mysql`
   - StatefulSet יחזיר Pod חדש ויחבר אותו לאותו PVC — בדוק שהנתונים עדיין קיימים.

## מה שצריך להגיש
- repo מלא (מבנה כפי שמוצג)
- תיאור של בדיקות שביצעת (README)
- קבצי manifests מפוצלים

## הערות אבטחה
- החלף את הסודות בערכים אמיתיים לפני ההגשה או השתמש ב-SealedSecrets / ExternalSecret ב-production.
