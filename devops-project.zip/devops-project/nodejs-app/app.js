const express = require('express');
const mysql = require('mysql2/promise');
const app = express();
const port = process.env.PORT || 3000;

// Health endpoint
app.get('/healthz', (req, res) => res.send('ok'));

app.get('/', async (req, res) => {
  try {
    const conn = await mysql.createConnection({
      host: process.env.DB_HOST || 'localhost',
      user: process.env.DB_USER || 'root',
      password: process.env.DB_PASS || '',
      database: process.env.DB_NAME || 'appdb',
    });
    const [rows] = await conn.query('SELECT NOW() as now');
    await conn.end();
    res.json({ message: 'Hello from NodeJS!', time: rows[0].now });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.listen(port, () => console.log(`App listening on ${port}`));
