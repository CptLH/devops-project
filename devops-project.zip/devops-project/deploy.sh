#!/bin/bash
set -e

# Usage: ./deploy.sh [build|apply|clean]
CMD=${1:-apply}
REGISTRY=${REGISTRY:-local}
IMAGE_NAME=${IMAGE_NAME:-devops-node-app}
TAG=${TAG:-latest}

if [[ "$CMD" == "build" ]]; then
  docker build -t $IMAGE_NAME:$TAG ./nodejs-app
  echo "Built $IMAGE_NAME:$TAG"
  exit 0
fi

if [[ "$CMD" == "apply" ]]; then
  kubectl apply -f k8s/namespace.yaml
  kubectl apply -f k8s/secrets.yaml
  kubectl apply -f k8s/mysql-statefulset.yaml
  kubectl apply -f k8s/nodejs-deployment.yaml
  kubectl apply -f k8s/apache-deployment.yaml
  kubectl apply -f k8s/services.yaml
  kubectl apply -f k8s/hpa.yaml
  kubectl apply -f k8s/ingress.yaml || true
  kubectl apply -f k8s/backup-cronjob.yaml
  echo "Applied manifests to namespace devops-project"
  exit 0
fi

if [[ "$CMD" == "clean" ]]; then
  kubectl delete namespace devops-project --ignore-not-found
  echo "Cleaned up"
  exit 0
fi

echo "Unknown command: $CMD"
exit 1
